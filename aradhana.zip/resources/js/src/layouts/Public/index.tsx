import React, { Children } from 'react';

const Public:React.FC = props =>{
  return(
    <>
    {props.children}
    </>
  )
}


export default Public;