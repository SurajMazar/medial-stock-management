import React from 'react';

const VendorCard:React.FC = ()=>{
  return(
    <>
    </>
  );
}

export default VendorCard;