export default [
  'admin',
  'sale',
  'lab'
]