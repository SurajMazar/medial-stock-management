import React from 'react';


const CustomerTransactions:React.FC = ()=>{
  return(
    <>
      Customer Transactions
    </>
  );
}

export default CustomerTransactions;