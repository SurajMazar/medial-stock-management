interface Currency{
  id:number,
  name:string,
  symbol:string,
  local_value:string,
  country:string,
  created_at:Date
}


export default Currency;