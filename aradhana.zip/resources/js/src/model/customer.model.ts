interface Customer{
  id:number,
  name:string,
  email:string,
  mobile:string,
  phone:string,
  description:string
}

export default Customer;