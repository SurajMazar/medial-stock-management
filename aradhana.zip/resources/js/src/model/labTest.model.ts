interface LabTest{
  id:number,
  name:string,
  tests?:string,
  created_at:Date
}


export default LabTest;