interface PageMeta{
  current_page:number,
  per_page:number,
  total:number
}

export default PageMeta;