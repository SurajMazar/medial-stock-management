<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row">
   
    
      
      
   
  </div>
  <div class="row pt-2">
    
    <div class="w-50 ml-auto">
      <p class="text-right"><span>Customer: </span><?php echo e($data->customer?$data->customer->name:$data->customer_name); ?></p>
      <p class="text-right"><span>Invoice No: </span><?php echo e($data->invoice_number?:""); ?></p>
      <p class="text-right"><span>Transaction Date: </span><?php echo e($data->transaction_date?date('F j, Y',strtotime($data->transaction_date)):""); ?></p>
    </div>
  </div>
  
  <div class="row">
    <h3 class="title text-center">
      Sales Invoice
    </h3>
  </div>

  <div>
    <table class="table">
      <thead>
        <tr>
          <th>Sn</th>
          <th>Item Description</th>
          <th>Batch</th>
          <th>Qty (Rs)</th>
          <th>Rate (Rs)</th>
          <th>Amount (Rs)</th>
        </tr>
      </thead>
      <tbody>
        <?php if(isset($data->sales) && count($data->sales)>0): ?>
          <?php $__currentLoopData = $data->sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($key+1); ?></td>
              <td><?php echo e($p->purchase?$p->purchase->product->name:''); ?></td>
              <td><?php echo e($p->purchase?$p->purchase->batch:''); ?></td>
              <td><?php echo e(salesQuantityFormatter($p)); ?></td>
              <td><?php echo e($p->rate); ?></td>
              <td><?php echo e($p->total); ?></td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
          <tr>
            <td colspan="6" class="text-center">Sorry no items found </td>
          </tr>
        <?php endif; ?>
      </tbody>
      <tfoot>
        <tr>
          <td colspan="5" class="text-left">
            Total
          </td>
          <td>
            <?php if(isset($data->sales) && count($data->sales)>0): ?>
              <?php
                $total = 0;
                foreach($data->sales as $p){
                  $total = $total+ $p->total;
                }
                echo 'Rs'. $total;
              ?>
              <?php else: ?>
              0
            <?php endif; ?>
          </td>
          <td></td>
        </tr>
      </tfoot>
    </table>
  </div>

  <div class="row">
    <div class="w-50 ml-auto">
      <table class="table">
        <tbody>
          <?php if(isset($data->alterations) && count($data->alterations)>0): ?>
            <?php $__currentLoopData = $data->alterations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($a->name); ?></td>
                <td><?php echo e($a->operation === "sub"?'-':"+"); ?> <?php echo e($a->amount); ?></td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?>
        </tbody>
        <tfoot>
          <tr>
            <td>Grand total</td>
            <td>Rs <?php echo e($data->amount); ?></td>
          </tr>
        </tfoot>
      </table>
    </div>
  </div>

  <div class="row pt-2">
   <?php if(isset($data->note)): ?>
   Note:<?php echo e($data->note); ?>

   <?php endif; ?>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php
  function salesQuantityFormatter ($item){
  if($item){    
      if($item->purchase && $item->purchase->product && $item->purchase->product->has_sub_units){
        $arr = explode('.',$item->quantity);
        if(count($arr)>1){
          
          return $arr[0].' unit  '.$arr[1]." ".$item->purchase->product->sub_unit_name;
        }
      }
    
    return $item->quantity;
  }

  return 0;
  }
?>
<?php echo $__env->make('pdf.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/suraz/personal/medial-stock-management/resources/views/pdf/sales_invoice.blade.php ENDPATH**/ ?>