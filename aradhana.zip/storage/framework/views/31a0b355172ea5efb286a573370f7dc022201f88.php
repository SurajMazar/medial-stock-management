<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row">
   
    
      
      
   
  </div>
  <div class="row pt-2">
    
    <div class="w-50 ml-auto">
      <p class="text-right"><span>Customer: </span><?php echo e($data->customer?$data->customer->name:$data->customer_name); ?></p>
      <p class="text-right"><span>Invoice No: </span><?php echo e($data->invoice_number?:""); ?></p>
      <p class="text-right"><span>Transaction Date: </span><?php echo e($data->invoice_date?date('F j, Y',strtotime($data->invoice_date)):""); ?></p>
    </div>
  </div>
  
  <div class="row">
    <h3 class="title text-center">
      Lab Invoice
    </h3>
  </div>

  <div>
    <?php if(isset($data->tests) && count($data->tests)): ?>
      <table class="table">
        <?php $__currentLoopData = $data->tests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tests): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <thead>
            <tr>
              <th colspan="3"><?php echo e($tests->name); ?></th>
            </tr>
          </thead>
      
          <?php if(isset($tests->tests) && count($tests->tests)>0): ?>
            <?php $__currentLoopData = $tests->tests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $test): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tbody>
              <tr>
                <th>Sn</th>
                <th>Name</th>
                <th>Price (Rs)</th>
              </tr>
              <tr>
                <td><?php echo e($key+1); ?></td>
                <td><?php echo e($test->name); ?></td>
                <td><?php echo e($test->price); ?></td>
              </tr>
            </tbody>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endif; ?>
      <tfoot>
        <tr>
          <td colspan="2" class="text-left">
            Total
          </td>
          <td>
            <?php if(isset($data->tests) && count($data->tests)>0): ?>
              <?php
                $total = 0;
                foreach($data->tests as $p){
                  foreach($p->tests as $t){
                    $total = $total + $t->price;
                  }
                }
                echo 'Rs'. $total;
              ?>
              <?php else: ?>
              0
            <?php endif; ?>
          </td>
          <td></td>
        </tr>
      </tfoot>
   </table>
  </div>

  <div class="row">
    <div class="w-100">
      <table class="table">
        <tbody>
          <?php if(isset($data->alterations) && count($data->alterations)>0): ?>
            <?php $__currentLoopData = $data->alterations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($a->name); ?></td>
                <td><?php echo e($a->operation === "sub"?'-':"+"); ?> <?php echo e($a->amount); ?></td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?>
        </tbody>
        <tfoot>
          <tr>
            <td>Grand total</td>
            <td>Rs <?php echo e($data->amount); ?></td>
          </tr>
        </tfoot>
      </table>
    </div>
  </div>

  <div class="row pt-2">
   <?php if(isset($data->note)): ?>
   Note:<?php echo e($data->note); ?>

   <?php endif; ?>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pdf.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/suraz/personal/medial-stock-management/resources/views/pdf/lab_invoice.blade.php ENDPATH**/ ?>