<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row">
   
    
      
      
  </div>
  <div class="row pt-2">
    <div class="w-50 ml-auto">
      <p class="text-right"><span>Customer: </span><?php echo e($data->customer?$data->customer->name:$data->customer_name); ?></p>
      <p class="text-right"><span>Invoice No: </span><?php echo e($data->invoice_number?:""); ?></p>
      <p class="text-right"><span>Transaction Date: </span><?php echo e($data->invoice_date?date('F j, Y',strtotime($data->invoice_date)):""); ?></p>
    </div>
  </div>
  
  <div class="row">
    <h3 class="title text-center">
      Lab Report
    </h3>
  </div>

  <div class="table-border">
    <?php if(isset($data->tests) && count($data->tests)): ?>
      <table class="table w-100">
        <?php $__currentLoopData = $data->tests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tests): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <thead>
            <tr>
              <th colspan="4"><?php echo e($tests->name); ?></th>
            </tr>
          </thead>
      
          <?php if(isset($tests->tests) && count($tests->tests)>0): ?>
            <?php $__currentLoopData = $tests->tests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $test): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tbody>
              <?php if($key === 0): ?>
              <tr>
                <th>Sn</th>
                <th>Name</th>
                <th>Normal</th>
                <th>Result</th>
              </tr>
              <?php endif; ?>
              <tr>
                <td><?php echo e($key+1); ?></td>
                <td><?php echo e($test->name); ?></td>
                <td><?php echo e($test->normal); ?></td>
                <td><?php echo e($test->result); ?></td>
              </tr>
            </tbody>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endif; ?>
   </table>
  </div>

  <div class="row pt-2">
   <?php if(isset($data->note)): ?>
   Note:<?php echo e($data->note); ?>

   <?php endif; ?>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pdf.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/suraz/personal/medial-stock-management/resources/views/pdf/lab_report.blade.php ENDPATH**/ ?>